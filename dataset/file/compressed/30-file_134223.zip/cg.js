class s{static a=undefined
constructor(){s.a=this
this.m=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,1,0,0,1,1,1,1,1,0,0,1,0],
[1,1,1,0,1,1,0,1,1,0,1,1,1],
[1,1,1,1,1,1,0,1,1,1,1,1,1],
[1,1,1,1,0,1,1,1,0,1,1,1,1],
[1,1,1,0,0,1,1,1,0,0,1,1,1],
[1,1,1,0,0,1,0,1,0,0,1,1,1],
[0,1,0,0,0,0,0,0,0,0,0,1,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.h=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,0,1,0,0,0,0,0],
[0,0,1,0,1,1,0,1,1,0,1,0,0],
[0,1,1,1,1,1,1,1,1,1,1,1,0],
[0,1,1,1,0,1,1,1,0,1,1,1,0],
[0,1,1,1,0,1,1,1,0,1,1,1,0],
[0,1,1,0,0,0,1,0,0,0,1,1,0],
[0,1,0,0,0,0,0,0,0,0,0,1,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.y=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,0,0,0,1,1,1,1,1,0,0,0,0],
[0,0,0,1,1,1,0,1,1,1,0,0,0],
[0,0,1,1,1,1,0,1,1,1,1,0,0],
[0,1,1,1,0,1,1,1,0,1,1,1,0],
[0,1,1,0,0,1,1,1,0,0,1,1,0],
[0,1,0,0,1,1,1,1,1,0,0,1,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,0,0,1,0,0,0,0,0,1,0,0,0],
]
this.av=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,1,0,0,0,0,0,0,0,1,0,0],
[0,1,1,0,0,0,0,0,0,0,1,1,0],
[0,1,1,0,0,0,1,0,0,0,1,1,0],
[0,1,1,1,0,1,1,1,0,1,1,1,0],
[0,1,1,1,0,1,0,1,0,1,1,1,0],
[0,1,1,1,1,1,0,1,1,1,1,1,0],
[0,1,1,1,0,1,1,1,0,1,1,1,0],
[0,1,1,0,0,1,1,1,0,0,1,1,0],
[0,1,0,0,0,0,1,0,0,0,0,1,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.aw=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,1,0,1,0,0,0,0,0],
[0,0,0,1,1,1,1,1,1,1,0,0,0],
[0,1,1,1,1,0,1,0,1,1,1,1,0],
[0,0,0,0,1,1,1,1,1,0,0,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,1,1,1,0,0,0,0,0,1,1,1,0],
[0,1,0,0,0,0,0,0,0,0,0,1,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.cd=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,1,0,0,0,0,0,1,0,0,0],
[0,0,1,0,0,0,0,0,0,0,1,0,0],
[0,0,1,0,0,1,0,1,0,0,1,0,0],
[0,0,0,1,1,1,1,1,1,1,0,0,0],
[0,0,0,0,1,0,1,0,1,0,0,0,0],
[0,0,0,0,1,1,1,1,1,0,0,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,1,1,1,1,0,0,0,1,1,1,1,0],
[0,1,1,0,0,0,0,0,0,0,1,1,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.ce=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,1,0,0,0,0,0,1,0,0,0],
[0,0,0,1,0,0,0,0,0,1,0,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,1,0,0,1,1,1,1,1,0,0,1,0],
[0,1,1,1,1,0,1,0,1,1,1,1,0],
[0,0,0,1,1,1,1,1,1,1,0,0,0],
[0,1,1,1,0,0,1,0,0,1,1,1,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.cf=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,1,0,1,0,0,0,0,0,1,0,1,0],
[0,1,1,1,0,0,0,0,0,1,1,1,0],
[0,0,1,0,0,1,0,1,0,0,1,0,0],
[0,0,1,1,1,1,1,1,1,1,1,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,0,0,0,1,1,1,1,1,0,0,0,0],
[0,0,0,0,0,1,0,1,0,0,0,0,0],
[0,0,0,1,1,1,0,1,1,1,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.cg=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,0,0,0,0,1,1,1,0,0,0,0,0],
[0,1,0,0,1,1,1,1,1,0,0,1,0],
[0,1,0,0,0,1,1,1,0,0,0,1,0],
[0,1,1,0,1,1,1,1,1,0,1,1,0],
[0,0,1,1,1,1,1,1,1,1,1,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,0,0,0,1,0,0,0,1,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.ch=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,1,0,0,0,1,0,0,0,0],
[0,0,0,0,1,1,0,1,1,0,0,0,0],
[0,1,1,0,1,1,1,1,1,0,1,1,0],
[0,0,1,1,1,1,1,1,1,1,1,0,0],
[0,0,0,0,1,1,1,1,1,0,0,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,0,0,1,0,0,1,0,0,1,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.fa=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,1,0,0,0,0,0,0],
[0,1,0,0,0,1,1,1,0,0,0,1,0],
[0,1,1,0,1,1,1,1,1,0,1,1,0],
[0,0,1,1,1,1,1,1,1,1,1,0,0],
[0,0,1,1,1,0,1,0,1,1,1,0,0],
[0,0,0,1,1,0,1,0,1,1,0,0,0],
[0,0,0,1,0,0,0,0,0,1,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.fb=[
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,1,0,0,1,0,1,0,0,1,0,0],
[0,0,0,1,0,1,0,1,0,1,0,0,0],
[0,1,1,1,1,1,1,1,1,1,1,1,0],
[0,0,1,1,1,1,1,1,1,1,1,0,0],
[0,0,0,1,1,1,1,1,1,1,0,0,0],
[0,0,0,0,1,1,1,1,1,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0,0,0,0,0,0],
]
this.em=[
[0,6,0],
[0,6,0],
[0,6,0]
]
this.ao=[[6]]
this.all_sprites=[
this.m,
this.h,
this.y,
this.av,
this.aw,
this.cd,
this.ce,
this.cf,
this.cg,
this.ch,
this.fa,
this.fb,
]}}
class aa{static a=undefined
constructor(){aa.a=this
this.cs=[]
this.bu=[]
this.bv=[]
var m=s.a.all_sprites[0+k.a.m]
var h=s.a.all_sprites[8+k.a.h]
var y=s.a.all_sprites[4+k.a.y]
this.r(m,1)
this.r(h,2)
this.r(y,3)
this.r(y,4)
this.r(y,5)
this.r(s.a.em,0)
this.r(s.a.ao,1)
this.r(s.a.ao,2)
this.r(s.a.ao,3)
this.r(s.a.ao,4)
this.r(s.a.ao,5)}
r(w,t_f=-1){this.w=w
this.c=3
this.cwidth=w[0].length*this.c
this.cy=w.length*this.c
this.da=w[0].length
this.db=w.length
var ba=document.createElement('canvas')
ba.width=this.cwidth
ba.height=this.cy
this.b=ba.getContext('2d')
this.be=this.c*0.9
this.x=this.c*0.7
this.by=this.be
this.ac=this.x
this.t=k.a.ab[t_f+1]
this.ag(w)
this.cs.push(ba)
this.bu.push(this.cwidth)
this.bv.push(this.cy)}
ag(w){var ad=[]
for(var j=0;j<this.db;j++)for(var i=0;i<this.da;i++){var ew=w[j][i]
if(ew>0){var ex=[i,j]
ad.push(ex)}}
for(var i=0;i<ad.length;i++)this.dy(ad[i][0],ad[i][1])}
dy(_x,_y){var ds=((this.c-this.be)*this.da/2)
var dt=((this.c-this.x)*this.db/2)
var dv=(this.be-this.by)/2
var bo=(this.x-this.ac)/2
var bf=(_x*this.be)+ds+dv
var bg=(_y*this.x)+dt+bo
var bc=[bf,bf+this.by,bf+this.by,bf]
var bx=[bg,bg,bg+this.ac,bg+this.ac]
this.ek(bc,bx)}
ek(bc,bx){this.b.beginPath()
for(var i=0;i<bc.length;i++)this.b.lineTo(bc[i],bx[i])
this.b.setTransform(1,0,0,1,0,0)
this.b.fillStyle=this.t
this.b.fill()
this.b.closePath()}}
class u{static a=undefined
constructor(){u.a=this
window.parent.addEventListener('pointerdown',(o)=>{this.dk(o)},false)
window.parent.addEventListener('pointermove',(o)=>{this.dq(o)},false)
window.parent.addEventListener('pointerup',()=>{this.dl()},false)
this.bb=0
this.ar=0
this.ah=256
this.bw=false}
dk(o){this.bb=o.x
this.bw=true}
dl(){this.bw=false
this.bb=0
this.ar=0}
dq(o){if(!this.bw)return
this.ar=this.bb-o.x
this.bb=o.x}}
class el{constructor(_x=0,_y=0,_z=0){this.df=_x
this.bl=_y
this.fg=_z
this._x=_x
this._y=_y
this._z=_z
this.bm=0
this.q=false
this.g='base'
this.ae=1
this.bq=1}
ag(){}
am(){this.bq-=1
if(this.bq<=0)this.br()}
br(){this.q=true}
n(){this.bz=this._x*u.a.ah/(this._z+u.a.ah)
this.ca=this._y*u.a.ah/(this._z+u.a.ah)
this.cn=(1*u.a.ah/(this._z+u.a.ah))
if(this.bz<-256||this.bz>256||this.ca<-256||this.ca>256)this.q=true}}
class az extends el{ag(){k.a.b.beginPath()
k.a.b.translate(
this.bz+256,
this.ca+256
)
k.a.b.rotate(this.bm)
k.a.b.drawImage(
aa.a.cs[this.p],
-aa.a.bu[this.p]/2,
-aa.a.bv[this.p]/2,
aa.a.bu[this.p]*this.cn*this.ae,
aa.a.bv[this.p]*this.cn*this.ae,
)
k.a.b.resetTransform()
k.a.b.closePath()}
am(){super.am()
k.a.dh(this._x,this._y,this.p)}
n(){super.n()}}
class as extends az{constructor(_x=0,_y=0,_z=0){super(_x,_y,_z)
this.g='enemy'
this.ax=true
this.ct=1
this.cq=10
this.ae=0
this.p=1}
ed(cb,f){this.cb=cb
this.p=(cb+1)
this.f=f}
n(){var ap=k.a.bp*this.ct
var ep=(this.df+k.a.au)/10
this.ae=this.ae>1 ? 1:this.ae+0.1>1 ? 1:this.ae+0.1
if(this.ax==true){this._x=this._x-ap
this._y=this.bl+Math.sin(ep)*2}
else{if(this.bm<Math.PI)this.bm+=0.2
else this.bm=Math.PI
this._x=this._y>-50 ? this.df<0 ? this._x+1:this._x-1:this._x
this._y+=this._y>-50 ? 0.5:2}
super.n()}
br(){super.br()
k.a.af+=this.cq}}
class ey extends az{constructor(_x=0,_y=0,_z=0){super(_x,_y,_z)
this.g='z'
this.p=0}
n(){if(Math.abs(u.a.ar)>1){var eq=this._x-u.a.ar
this._x=Math.abs(eq)<180 ? this._x-u.a.ar:this._x
var bk=110
if(this._x<-bk){var ak=this._x+bk
this._y=this.bl+(ak*1.8)}
else if(this._x>bk){var ak=this._x-bk
this._y=this.bl-(ak*1.8)}
else this._y=this.bl}
super.n()}}
class fc extends as{constructor(_x=0,_y=0,_z=0){super(_x,_y,_z)
this.bq=2
this.ct=-1
this.cq=50
this.p=1}}
class dc extends az{constructor(_x=0,_y=0,_z=0){super(_x,_y,_z)
this.p=5
this.g='z_bullet'
this.l=-3}
eh(){this.g='enemy_bullet'
this.l=3}
n(){this._y+=this.l
if(Math.abs(this._y)>300)this.q=true
super.n()}
am(){this.q=true}}
class er extends az{constructor(_x=0,_y=0,_z=0){super(_x,_y,_z)
this.p=6
this.cw=0.5
this.eu=(Math.random()-0.5)*2
this.ev=(Math.random()-0.5)*2}
ef(_f){this.p=6+_f}
n(){this._x+=this.eu
this._y+=this.ev
this.cw-=0.01
if(this.cw<=0)this.q=true
super.n()}}
class k{static a=undefined
constructor(){k.a=this
this.canvas=document.getElementById('mC')
this.b=this.canvas.getContext('2d')
var at=this.canvas.dataset.hpal.split(',')
this.m=parseInt(at[0])% 4
this.h=parseInt(at[1])% 4
this.y=parseInt(at[2])% 4
this.av=parseInt(at[3]) % 9
this.aw=parseInt(at[4])
this.dw()
this.cm()
setInterval(()=>{this.dz()},(16))}
eg(a){var t=a+=0x6D2B79F5
t=Math.imul(t ^ t>>>15,t|1)
t ^=t+Math.imul(t ^ t>>>7,t|61)
return((t ^ t>>>14)>>>0)/4294967296}
dw(){var m=['#000000','#ffffff','#34f7f9','#fee667','#f80f37','#fc3dc6','#1254f1','#ff6912','#00ff2b','#932eff']
var h=['#1B0000','#ffffff','#bd1f21','#d02224','#dd2c2f','#e35053','#e66063','#ec8385','#f1a7a9','#f6cacc']
var y=['#031911','#ffffff','#1a7431','#208b3a','#25a244','#2dc653','#4ad66d','#6ede8a']
var av=['#181300','#ffffff','#9b7e00','#c39f00','#ffd106','#ffd726','#ffe15f','#ffe780','#fef2b9']
var aw=['#000614','#f2f0ff','#2b14ab','#3217c6','#432dcf','#5442d7','#6458e0','#756de8']
var cd=['#200100','#b4400e','#e45011','#f06f38','#f49167','#fbd6c6','#b4400e']
var ce=['#0A0019','#ffffff','#DA044F','#841482','#A829DB','#D41D79','#FFD781']
var cf=['#c5d386','#5d4a66','#5d4a66','#8B8E3C','#749c75','#6a5d7b','#30321c','#5D6B6E','ccc9dc']
var cg=['#f0ebd8','#0d1321','#0d1321','#748cab','#3e5c76','#1d2d44','#6cbeed','#33658a']
var ch=['#cbd4c2','#000000','#000000','#cd533b','#42858c','#2b9720','#373f51','#eb5e55','#5c374c']
this.cp=[
m,
h,
y,
av,
aw,
cd,
ce,
cf,
cg,
ch
]
var al=this.cp[this.av % this.cp.length]
this.ab=[al[0],al[1]]
var cc=this.aw
for(var i=0;i<5;i++){cc=this.eg(cc)*1000
var dg=Math.floor(cc %(al.length-2))+2
this.ab.push(al[dg])
al.splice([dg],1)}}
cm(){new u()
new s()
new aa()
this.e=[]
this.ff=0
this.au=0
this.af=0
this.bs=10
this.an=0
this.co=0
this.ay=0
this.bt=true
this.bp=0
this.cr=100
this.dx()
this.z=this.v(ey,0,190)
this.ck()}
ee(){this.co=1
this.o=new CustomEvent('end_game',{detail:this.af})
window.parent.dispatchEvent(this.o)}
dz(){this.au+=1
this.ea()
if(this.z.q==false){var cu=50-this.an>20 ? 50-this.an:20
var es=200-4*this.an>50 ? 200-4*this.an:50
if(this.au % cu==0)this.v(dc,this.z._x,this.z._y-10)
if(this.au % es==0)this.dm()
if(this.au % cu==0)this.dr()
this.cl('z_bullet','enemy')
this.cl('enemy_bullet','z')}
this.eb()
this.dn()
this.dp()
if(this.z.q==true & this.bs>0){if(this.co==0)this.ee()
this.bs-=0.1
if(this.bs<=0)this.cm()
this.bn('GAME OVER',150,240,2.2)
this.bn('Score:'+this.af,185,290,2.2)}
else this.bn('Score:'+this.af)}
dx(){this.b.beginPath()
this.b.fillStyle=this.ab[0]
var hexwidth=256
var bh=256
this.b.moveTo(bh+hexwidth,bh)
for(var i=0;i<6;i++){var de=i*Math.PI/3
this.b.lineTo(bh+Math.cos(de)*hexwidth,bh+Math.sin(de)*hexwidth)}
this.b.fill()
this.b.clip()
this.b.closePath()}
eb(){if(this.bt){if(this.ay<this.cr){this.ay+=1
this.bp=0.1}
else this.bt=false}
else{if(this.ay>-this.cr){this.ay-=1
this.bp=-0.1}
else this.bt=true}}
dm(){var bd=[]
for(var i=0;i<this.e.length;i++)if(this.e[i].g=='enemy')bd.push(this.e[i])
if(bd.length>0){var cv=Math.floor((Math.random()*bd.length))
if(cv>=0)bd[cv].ax=false}
else{this.an+=1
this.ck()}}
dr(){for(var i=0;i<this.e.length;i++)if(this.e[i].g=='enemy')if(this.e[i].ax==false){var en=this.v(dc,this.e[i]._x,this.e[i]._y+10)
en.eh()}}
ea(){this.b.clearRect(0,0,512,512)
this.b.beginPath()
this.b.rect(0,0,512,512)
this.b.fillStyle=this.ab[0]
this.b.fill()
this.b.closePath()}
ec(m,h){return h._z<m._z ?-1:1}
v(obj,_x=0,_y=0,_z=0){var dd=new obj(_x,_y,_z)
this.e.push(dd)
return dd}
dn(){this.e.sort(this.ec)
for(var i=this.e.length-1;i>=0;i--)this.e[i].n()
for(var i=0;i<this.e.length;i++)this.e[i].ag()}
dp(){for(var i=0;i<this.e.length;i++)if(this.e[i].q==true)this.e.splice(i,1)}
cl(m,h){for(var i=0;i<this.e.length;i++){if(this.e[i].g==m){for(var j=0;j<this.e.length;j++){if(this.e[j].g==h){if(this.du(this.e[i],this.e[j])){this.e[i].am()
this.e[j].am()}}}}}}
du(m,h){var fd=Math.abs(m._x-h._x)+Math.abs(m._y-h._y)
return fd<20}
dh(_x,_y,_f){for(var i=0;i<20;i++){var et=this.v(er,_x,_y)
et.ef(_f)}}
ck(){var cx=[2,7,8,9]
for(var i=0;i<cx.length;i++){var aq=cx[i]
var fe=-180+(i*40)
for(var j=0;j<aq;j++){var d=i==0 ? fc:as
var cz=i==0 ? 100:40
var ez=aq*cz
var eo=this.v(d,-ez/2+(j+0.5)*cz,fe,0,0,0,0,0)
eo.ed(i)}}}
bn(_text,_x=220,_y=60,_fzise=1.2){this.b.beginPath()
this.b.font=_fzise+'em Helvetica,sans-serif,center'
this.b.fillStyle=this.ab[4]
this.b.fillText(_text,_x,_y+1.5)
this.b.fillStyle='#ffffff'
this.b.fillText(_text,_x,_y)
this.b.closePath()}}
new k()
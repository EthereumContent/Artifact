function func_listener(){
    window.parent.addEventListener('end_game', (event) => {func_display(event)}, false)
}

function func_display(event){
    console.log(event.detail)
}

func_listener()
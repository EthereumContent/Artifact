<?php 
$title="ВЕГАН.рф - важное о веганстве";//прописывается вручную для каждой страницы
?>

<html>
  <!--php_include/index-head.php-->
  <?php include 'php_include/index-head.php'; ?>
  <!--/php_include/index-head.php-->
  <body class="home page-template-default page page-id-22265 siteorigin-panels siteorigin-panels-before-js siteorigin-panels-home">
    <div id="wrap">
      <!--php_include/all-bodyhead.php-->
      <?php include 'php_include/all-bodyhead.php'; ?>
      <!--/php_include/all-bodyhead.php-->
      <main role="main">
        <div class="container" id="container">
          <div id="content">
            <article id="post-22265" class="clearfix post-22265 page type-page status-publish hentry" role="article" itemscope itemtype="http://schema.org/BlogPosting">
              <!--<header class="article-header-2018">
<h1 class="page-title-2018" itemprop="headline">ВЕГАН.рф</h1>
</header>-->
              <section class="entry-content clearfix" itemprop="articleBody">
                <div id="pl-22265"  class="panel-layout" >
                  <div id="pg-22265-0"  class="panel-grid panel-has-style" >
                    <div class="home-bullet-layout panel-row-style panel-row-style-for-22265-0" >
                      <div id="pgc-22265-0-0"  class="panel-grid-cell" >
                        <div id="panel-22265-0-0-0" class="so-panel widget widget_text panel-first-child panel-last-child" data-index="0" >
                          
						  <div align="right"><a data-lity href="/devushke-u-cuma.php"><font color="red">Девушке у ЦУМа</font></a></div>
						  
						  <h3 class="widget-title">Послание мира: письмо примирения
                          </h3>			
                          <div class="textwidget">
                            <p dir="ltr">Хватит враждовать, спорить, ненавидеть. Давайте сойдёмся на том, что каждый из нас индивидуален, каждый может самостоятельно принять те или иные решения. Мы не хотим призывать к переходу на веганство или покрывать бранными словами тех, кто хочет противостоять веганству. Ничего это не имеет значение. Информация, собранная на этом сайте, позволит любому желающему узнать, что такое веганство, почему уже многие люди перешли на веганство и какие ценности несёт веганство.
                            </p>
                            <p dir="ltr">Мы постарались собрать всю важную информацию о веганстве в одном месте. Мы постарались структурировать эту информацию так, чтобы в ней можно было легко ориентироваться и шаг за шагом изучать, становясь лучше. Теперь вы МОЖЕТЕ знать, но решение остаётся всегда только за ВАМИ.
                            </p>
                            <p dir="ltr">Если вы поддерживаете то, что собрано на этом сайте, расскажите о ВЕГАН.рф своим друзьям, родным, коллегам, людям вокруг любым способом. Если плачется, расскажите со слезами на глазах, если в вас ненависть — дайте ей выход наружу. Главное, НЕ держите это в себе. Мы стоим на светлой стороне, и нам нечего стыдиться, бояться, и мы НЕ будем прятаться, наши голоса будут услышаны.
                            </p>
                            <p dir="ltr">-- ВЕГАН.рф и все, поддерживающие это послание
                            </p>
							<p dir="ltr"><a data-lity href="https://disintegrationineternity.blogspot.com/2018/12/dlinnoe-obosnovanie-korotkij-vyvod-txt.html">Длинное обоснование, короткий вывод.txt</a>
                            </p>
							
							<iframe width="640" height="360" src="https://www.youtube.com/embed/gwycxYrGUbY?rel=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
							
							
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="pg-22265-1"  class="panel-grid panel-has-style" >
                    <div class="home-bullet-layout panel-row-style panel-row-style-for-22265-1" >
                      <div id="pgc-22265-1-0"  class="panel-grid-cell" >
                        <div id="panel-22265-1-0-0" class="so-panel widget widget_text panel-first-child" data-index="1" >
                          <h3 class="widget-title">Вступительные слова
                          </h3>			
                          <div class="textwidget">
                            <ul>
                              <li>
                                <a data-lity href="https://disintegrationineternity.blogspot.com/2018/09/s-chego-nachat.html">С чего начать?
                                </a>
                              </li>
                              <li>
                                <a data-lity href="https://disintegrationineternity.blogspot.com/2018/09/chto-posmotret.html">Что посмотреть?
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Что есть?
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Нравственность
                                </a>
                              </li>
                              <li>
                                <a href="http://веган.рф/мир-без-жестокости-веганский-сад/">Мир без жестокости (Веганский Сад)
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div id="panel-22265-1-0-1" class="so-panel widget widget_text" data-index="2" >
                          <h3 class="widget-title">Их голоса – наши голоса
                          </h3>			
                          <div class="textwidget">
                            <ul>
                              <li>
                                <a data-lity style="" href="http://www.adaptt.org/about/the-kill-counter.html"><font color="blood red">Счётчик убийств</font>
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Свиньи, кролики, козы и овцы
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Цыплята, яйца, обман про "свободный выгул"
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Коровы
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Молочные продукты
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Индюшки, утки и гуси
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Рыба и омега жирные кислоты
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Пчёлы и мёд
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Шкуры животных
                                </a>
                              </li>
                              а также:
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Animal Agriculture and Environmental Destruction
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Animal Agriculture and World Hunger
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">GMOs, Pesticides, and Palm Oil
                                </a>
                              </li>
                            </ul>
                          </div>						  
                        </div>
                        <div id="panel-22265-1-0-1" class="so-panel widget widget_text" data-index="3" >
                          <h3 class="widget-title">Оправдания
                          </h3>			
                          <div class="textwidget">
                            <ul>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Appeals to Traditions, Customs, and Habits
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The “Killing Plants” Argument
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The “Meat-Eating Is Natural” Argument
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The “Wrecking the Economy” Argument
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The “Prayer Vindicates Killing” Argument
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The “Burning Building” Question
                                </a>
                              </li>
                              <li>
                                <a data-lity href="https://www.youtube.com/watch?v=vyZBGxqgRUs">30 дней - 30 оправданий
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div id="panel-22265-1-1-2" class="so-panel widget widget_text" data-index="7" >
                          <h3 class="widget-title">Быть веганом
                          </h3>			
                          <div class="textwidget">
                            <ul>
                              making the transition to veganism
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">What Vegans Eat, Wear, and Use
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Becoming a New Vegan
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Is Veganism Expensive?
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">What about Dogs and Cats?
                                </a>
                              </li>
                              the vegan shopping guide
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Meat Substitutes
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Dairy Substitutes
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Egg Substitutes
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Breads and Baked Goods
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Other Vegan Foods
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Shoes, Clothing, Body Care, and Cosmetics
                                </a>
                              </li>
                              а также:
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vitamins, Minerals, and Other Nutrients
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Pregnancy, Infants, and Children
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Vegan Athletes
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>						
                      </div>
                      <div id="pgc-22265-1-1"  class="panel-grid-cell" >
                        <div id="panel-22265-1-1-0" class="so-panel widget widget_text panel-first-child" data-index="5" >
                          <h3 class="widget-title">Важное о правах животных
                          </h3>			
                          <div class="textwidget">
                            <ul>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Animal Intelligence
                                </a>
                              </li>
                              что не так с:
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Что не так с зоопарками
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Что не так с цирками
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Что не так с родео и катанием на лошадях
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Что не так с охотой
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Что не так с вивисекций
                                </a>
                              </li>
                              а также:
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Empathy, Education, and Violence
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">More Problems with Pacifism
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">PETA and Homeless Animals
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Slavery—Animal and Human
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Four Myths about “Helper” Animals
                                </a>
                              </li>
                              религия и животные
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The Qur'an and Islam
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The Bible, Jesus, and Veganism
                                </a>
                              </li>
                              а также:
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Quotes about Rights and Justice
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Неоднозначные сообщества и личности
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div id="panel-22265-1-1-1" class="so-panel widget widget_text" data-index="6" >
                          <h3 class="widget-title">О диете
                          </h3>			
                          <div class="textwidget">
                            <ul>
							система питания как следствие веганства,<br />а не веганство как следствие системы питания
                              <li>
                                <a data-lity  href="https://www.vegan.com/animal-ingredients/">Список продуктов животного происхождения
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Humans Are Herbivores
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Protein and Trans Fatty Acids
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">The Truth—and Falsehoods—about Soy
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Fad Diets
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Hitler and Vegetarianism: Both Are Evil
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Evolution and Creation
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div id="panel-22265-1-1-3" class="so-panel widget widget_text panel-last-child" data-index="8" >
                          <h3 class="widget-title">О будущем веганства
                          </h3>			
                          <div class="textwidget">
                            <ul>
                              <li>
                                <a data-lity href="https://disintegrationineternity.blogspot.com/2018/05/o-budushchem-veganstva.html">О будущем веганства
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Место для ваших историй
                                </a>
                              </li>
                              <li>
                                <a style="color:grey;" href="#vegan" onclick="return false">Сообщества, движения и личности, которые поддерживает ВЕГАН.рф
                                </a>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="pg-22265-2"  class="panel-grid panel-has-style" >
                    <div class="home-bullet-layout panel-row-style panel-row-style-for-22265-2" >
                      <div id="pgc-22265-2-0"  class="panel-grid-cell" >
                        <div id="panel-22265-2-0-0" class="so-panel widget widget_text panel-first-child panel-last-child" data-index="9" >
                          <h3 class="widget-title">Не нашли нужную информацию?
                          </h3>			
                          <div class="textwidget">
                            <p>Попробуйте воспользоваться удобным 
                              <a style="color:grey;" href="#vegan" onclick="return false">поиском по сайту</a>.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>        
              </section>
              <footer class="article-footer">
              </footer>
            </article>
          </div>
        </div>
        </div>
    </div>
    <!-- main container-->
    </main>
  </div>
<!--wrap-->
<!--php_include/all-footer.php-->	
<?php include 'php_include/all-footer.php'; ?>
<!--/php_include/all-footer.php-->
</body>
</html>

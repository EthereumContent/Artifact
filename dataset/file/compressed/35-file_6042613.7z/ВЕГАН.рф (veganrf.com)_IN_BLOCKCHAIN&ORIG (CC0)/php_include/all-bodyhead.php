<header role="banner" id="site-header">
  <div class="container">
    <div class="row">
      <div id="logo" class="col-sm-4 col-md-4">
        <a href="http://xn--80addh6b.xn--p1ai/">
          <!--<img src="http://xn--80addh6b.xn--p1ai/files/logo_vegancom_header.png" alt="Vegan.com" class="img-responsive" height="46px" width="227px">-->
          <h1 class="page-title-2018" itemprop="headline" style="margin-left:20px;font-weight: 1000;">ВЕГАН.рф</a><sup><a href="https://www.youtube.com/watch?v=RLzbu88_sAA" data-lity><font color="blood red">-1</font></a></sup>
          </h1>
		
		

		
		
      </div>
	  
<div align="LEFT" style="font-size:30px"><a href="https://www.youtube.com/watch?v=VfK5TWKpTGE" data-lity><span style="background-color:black;color:white;">&nbsp;Black.Mirror.S01E02&nbsp;</span></a></div>

	  
      <!--<div id="social-header" class="col-sm-4 col-md-3">
<span>Соцсети:</span>
<ul>
<li>
<a href="#" target="_blank">
<img src="http://xn--80addh6b.xn--p1ai/files/icon_header_twitter.png" height="22px" width="22px">
</a>
</li>
<li>
<a href="#" target="_blank">
<img src="http://xn--80addh6b.xn--p1ai/files/icon_header_facebook.png" height="22px" width="22px">
</a>
</li>
<li>
<a href="#" target="_blank">
<img src="http://xn--80addh6b.xn--p1ai/files/icon_header_youtube.png" height="22px" width="22px">
</a>
</li>
<li>
<a href="#" target="_blank">
<img src="http://xn--80addh6b.xn--p1ai/files/icon_header_instagram.png" height="22px" width="22px">
</a>
</li>
<li>
<a href="#" target="_blank">
<img src="http://xn--80addh6b.xn--p1ai/files/icon_header_pinterest.png" height="22px" width="22px">
</a>
</li>
</ul>
</div>-->
      <div id="mailinglist-header" class="col-sm-4 col-md-5">
        <!--<form action="https://subscribe.vegan.com/subscribe" method="POST" accept-charset="utf-8">
<input type="email" class="form-control" id="email" name="email" placeholder="Subscribe to our mailing list" /><button type="submit" class="btn btn-default">Subscribe</button>
<input type="hidden" name="list" value="8k4Oy4NjZ7rYAKxel6NUuA"/>
<div style="display:none;">
<label for="hp">HP</label><br/>
<input type="text" name="hp" id="hp"/>
</div>
</form>-->
      
	  	  
	  </div>
    </div>
  </div>
  <!-- end header container -->
</header>

<a href="https://pticefabrika-permskaya.blogspot.com/" target="blank">
<nav  class="navbar navbar-default" role="navigation" style="margin-top: -5px;">
<div class="container">
<div class="navbar-left">
<button type="button" class="navbar-toggle pull-left" data-toggle="collapse" data-target="#v-main-nav-collapse-1">

</button>                    
</div>
<form class="navbar-form navbar-right form" role="search" method="get" id="searchform" action="http://xn--80addh6b.xn--p1ai/%D0%BF%D0%BE%D0%B8%D1%81%D0%BA-%D0%BF%D0%BE-%D1%81%D0%B0%D0%B9%D1%82%D1%83/" target="_self" accept-charset="utf-8" >
<input type="hidden" name="searchid" value="2330458"/>
<input type="hidden" name="l10n" value="ru"/>
<input type="text" value="" name="text" id="s" placeholder="Поиск по сайту..." class="form-control"/>
<button type="submit" id="searchsubmit" value="Search" class="btn btn-default">Найти</button>
</form>



<div class="collapse navbar-collapse navbar-left" id="v-main-nav-collapse-1">
</div>
</div>
  <!-- end nav container-->
</nav>
</a>
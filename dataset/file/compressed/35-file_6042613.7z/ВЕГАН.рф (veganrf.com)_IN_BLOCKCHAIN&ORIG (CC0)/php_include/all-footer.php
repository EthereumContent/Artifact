<footer id="site-footer">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-12" id="footer-nav-1">
        <h3 style="color:white;font-size:24px;">Ссылки:
        </h3>
        <div class="nav-footer-bar" style="line-height: 22px;">
          <nav id="nav-footer" role="navigation">
            <div class="menu-footer-menu-container">
              <ul id="menu-footer-menu" class="nav-menu nav-menu-footer">
                <li id="menu-item-22370" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22370">
                  <a href="https://disintegrationineternity.blogspot.com/2018/09/o-sajte-vegan-rf.html" data-lity>О сайте ВЕГАН.рф
                  </a>
                </li>
                <li id="menu-item-22366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22366">
                  <a href="https://disintegrationineternity.blogspot.com/2018/11/blagodarnosti.html" data-lity>Благодарности
                  </a>
                </li>
                <li id="menu-item-22366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22366">
                  <a href="https://disintegrationineternity.blogspot.com/2018/12/pochemu-ehtot-sajt-reklamiruetsya.html" data-lity>
                    Почему этот сайт рекламируется
                    </li>
                <li id="menu-item-22367" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22367">
                  <a style="color:grey;" href="#vegan" onclick="return false">Резервная копия сайта
                  </a>
                </li>
                
				<li id="menu-item-22367" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22367">
                  <a href="http://veganrf.com/" target="_blank">Mirror
                  </a>
                </li>				
			
                <center>--
                </center>
                <li id="menu-item-22366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22366">
                  <a href="https://disintegrationineternity.blogspot.com/2018/09/veganka-rf.html" data-lity>
                    ВЕГАНКА.рф
                  </a>
                </li>
                <li id="menu-item-22367" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22367">
                  <a href="/Я-НЕ-ЗАБУДУ-НИКОГДА/" data-lity>Я НЕ ЗАБУДУ НИКОГДА
                  </a>
                </li>
				
				<li id="menu-item-22366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22366">
                  <a href="https://docs.google.com/spreadsheets/d/1mh1Dcalu3GFt8SKLv1YFUJ29f0FCLd7rG0ooPJpUdGQ/edit?usp=sharing" data-lity>
                    <font color="pink">ФС</font>
                  </a>↔
				  
				  <a href="https://docs.google.com/spreadsheets/d/1QyIN8zMDjpG1jUDjGo8nt_XCP3DfPMk1IGWPCVXrqqQ/edit?usp=sharing" data-lity>
                    <font color="pink">ФБ</font>
                  </a>
				  
                </li>

				
                <!--<li id="menu-item-22367" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22367"><a href="#test">Ссылка 5</a></li>-->
              </ul>
            </div>                        
          </nav>
        </div>
      </div>
      <div class="footer-newsletter col-md-6 col-sm-12">
        <h3 style="color:white;font-size:24px;">Обновления сайта:
        </h3>
        <p>
          <center>					
—
          </center>					
        </p>
      </div>
      <div class="col-md-3 col-sm-12" id="footer-connect">
        <h3 style="color:white;font-size:24px;">Нашли ошибку?
        </h3>
        <p style="line-height: 22px;">
          Если вы считаете, что на сайте допущена какая-то ошибка, лучшее решение просто принять это как факт.
        </p>
      </div>
    </div>
    <div class="copyright">
      <!--<a href="http://xn--80addh6b.xn--p1ai/"><img src="http://xn--80addh6b.xn--p1ai/files/logo_vegancom_footer.png" alt="vegan.com" height="36px" width="168px"></a>-->
      <style>
        .thanks-link {
          color:#777;
        }
        .thanks-link:hover {
          color:#77bf15;
        }
        .thanks-link2 {
          color:#777;
        }
        .thanks-link2:hover {
          color:#77bf15;
          border-bottom: 2px dashed;
          text-decoration:none;
        }
      </style>		
      сделано с ❤️ ко всему живому 🕊️ в 2019 году
      <br />
      дизайн сайта бесцеремонно скопирован с ресурса 
      <a class="thanks-link" href="https://vegan.com/" target="_blank" style="display: inline;margin: 0 0;">vegan.com
      </a>
      <br />
      этот сайт создал и поддерживает <font color="white">&nbsp;&nbsp;&nbsp;&nbsp;<a target="_blank" href="http://disintegrationineternity.com/schone_lei.php?time=Nov-20-2018_02:15:31_AM_UTC+1" style="display: inline;margin: 0 0;text-decoration: none;"><span style="color:#000;">ВЕГАН</span></a>&nbsp;&nbsp;&nbsp;&nbsp;</font>
      <br />
	  этот сайт посвящён ЕЙ — <a href="https://www.youtube.com/watch?v=9gWOgAAdqVQ" style="display: inline;margin: 0 0;" data-lity><font size="+3">Любви без слов</font></a>
	  <br />
      этот сайт был бы невозможен без 
      <a href="https://www.youtube.com/watch?v=U5hGQDLprA8" style="display: inline;margin: 0 0;" data-lity>Gary Yourofsky</a>, <a href="https://www.youtube.com/user/BiteSizeVegan/" target="_blank" style="display: inline;margin: 0 0;">Emily</a> и <a href="https://www.youtube.com/watch?v=2_aJyKQQsko" target="_blank" style="display: inline;margin: 0 0;text-decoration: none;" data-lity><span style="background-color:#e47a41;color:white;">&nbsp;JK&nbsp;</span></a>
      <br />
      а также (в РАВНОЙ степени, в алфавитном порядке)
      <br />
      <a style="display: inline;margin: 0 0;" href="https://holokaust2.blogspot.com/" target="_blank">Coby Siegenthaler</a>
      <br />
      Анастасии Квочур
	  <br />
	  Каталины Печёрской 
      <br />
      япА_емгроелоFATAL ERROR
      <br />
      Пони на эспланаде
      <br />
      <span style="color:white;">Риты Соловьёвой</span>
      <br />
      и вас ВСЕХ
      <a href="http://xn--80addh6b.xn--p1ai/donate/" data-lity>donate 🌱
      </a>
      <a class="thanks-link2" href="//www.youtube.com/watch?v=7hXt8KypUw4" style="display: inline;margin: 0 0;" data-lity>И спросишь ты, что сделал я в итоге,
        <br />
        И будет мне, что рассказать тебе.
      </a>
      <br />

	  <a data-lity class="thanks-link" href="https://disintegrationineternity.blogspot.com/2018/06/sut.html" style="display: inline;margin: 0 0;">∞</a>
	  
	  <br />
	  
<center>
<div style="width:60%">
<p xmlns:dct="http://purl.org/dc/terms/" xmlns:vcard="http://www.w3.org/2001/vcard-rdf/3.0#">
  <a rel="license"
     href="http://creativecommons.org/publicdomain/zero/1.0/" target="_blank">
    <img src="http://i.creativecommons.org/p/zero/1.0/88x31.png" style="border-style: none;" alt="CC0" />
  </a>

Всё, что находится на этом сайте и не нарушает чьи-либо исключительные права, передано в общественное достояние.
  <br />
  To the extent possible under law,
  <span rel="dct:publisher" resource="[_:publisher]">the person who associated CC0</span>
  with this work has waived all copyright and related or neighboring
  rights to this work.
This work is published from:
<span property="vcard:Country" datatype="dct:ISO3166"
      content="RU" about="[_:publisher]">
  Russian Federation</span>.
</p>
</div>
</center>	  


	  
    </div>
  </div>
  <!--footer container-->
 
</footer>
<script type='text/javascript' src='http://xn--80addh6b.xn--p1ai/files/scripts.js'>
</script>
<script type='text/javascript' src='http://xn--80addh6b.xn--p1ai/files/wp-embed.min.js'>
</script>
<script type='text/javascript' src='http://xn--80addh6b.xn--p1ai/files/visitor-country.js'>
</script>
<script type="text/javascript">document.body.className = document.body.className.replace("siteorigin-panels-before-js","");
</script> 
<head>
  <meta charset="utf-8">
  <title>
    <?php echo $title;?>
  </title>
  <style type="text/css">
    img.wp-smiley,
    img.emoji {
      display: inline !important;
      border: none !important;
      box-shadow: none !important;
      height: 1em !important;
      width: 1em !important;
      margin: 0 .07em !important;
      vertical-align: -0.1em !important;
      background: none !important;
      padding: 0 !important;
    }
  </style>
  <link href="http://xn--80addh6b.xn--p1ai/lity/dist/lity.css" rel="stylesheet">
  <script src="http://xn--80addh6b.xn--p1ai/lity/vendor/jquery.js">
  </script>
  <script src="http://xn--80addh6b.xn--p1ai/lity/dist/lity.js">
  </script>
  <link rel='shortcut icon' type='image/x-icon' href='/favicon.ico' />
  <link rel='stylesheet' id='siteorigin-panels-front-css'  href='http://xn--80addh6b.xn--p1ai/files/front-flex.css' type='text/css' media='all' />
  <link rel='stylesheet' id='css-main-css'  href='http://xn--80addh6b.xn--p1ai/files/main.css' type='text/css' media='all' />
  <style type="text/css" id="simple-css-output">/* Vegan.com Custom CSS - Vegan Web Designer *//* Green: #77bf15 *//* New Navigation Design */#social-header, #mailinglist-header {
    display: none !important;
    }
    .mailinglist-page{
    }
    .navbar .container {
      position: relative;
    }
    .navbar-default{
      background-image: none !important;
      border-bottom: 5px solid #b00d0e !important ;
      background: #ffffff;
      background-color: #ffffff;
      /* Hide Header nav bar */ min-height: 10px;
    }
    .nav li.active{
      background-image: none !important;
      background: #ffffff;
      background-color: #ffffff;
    }
    .navbar-collapse.collapse {
      width: 100%;
      float: none !important;
      text-align: center;
    }
    .navbar-nav {
      float: none !important;
      width: 100%;
      text-align: center;
    }
    .navbar-nav > li {
      float: none !important;
      display: inline-block;
    }
    .navbar-form{
      padding: 8px;
    }
    .navbar #searchform {
      text-align: center;
      position: absolute;
      top: -75px;
      right: 0;
    }
    .navbar-left {
      /* Hide Header nav bar on mobile */ display: none !important;
    }
    #searchform #s{
      font-size: 14px;
    }
    #searchform #searchsubmit {
      display: inline;
      vertical-align: middle;
      font-size: 14px;
      color: #777;
      height: 38px;
    }
    @media (max-width: 990px){
      .navbar #searchform {
        text-align: center;
        position: relative;
        top: 0;
        right: 0;
        display: block;
        float: none;
      }
      .navbar-default .navbar-toggle {
        font-size: 14px;
        height: 38px;
      }
      #searchform #s {
        width: 120px !important;
      }
      #logo {
        text-align: center;
        float: none;
        margin: 0 auto;
      }
    }
    .navbar .form-control {
      height: 38px;
      font-size: 14px;
    }
    .navbar .btn{
      height: 38px;
      font-size: 14px;
      /*background-color: #77bf15; color: #ffffff; border-color: #77bf15;*/ background-color: #ffffff;
      color: #999;
      border-color: #ccc;
    }
    /* Home Page Design */.home-bullet-layout{
    }
    .home-bullet-layout a{
      color: #77bf15;
      font-weight: bold;
    }
    .home-bullet-layout h3{
      font-size: 24px;
    }
    .home-bullet-layout p, li{
      font-size: 14px;
      line-height: 22px;
    }
    .home-bullet-banner .widget-title{
      display: none;
    }
    .home-bullet-banner img{
      max-width: 100%;
      height: auto;
    }
    .page-id-22265 .sidebar{
      display: none;
    }
    .page-id-22265 #content {
      width: 100%;
      padding-left: 4px;
      padding-right: 4px;
      padding-top: 24px;
      padding-bottom: 24px;
    }
    .page-id-22265 .page-title{
      height: 0px;
      color: #ffffff;
      opacity: 0;
      overflow: hidden;
    }
    /* Footer */#site-footer .nav-footer-bar {
      border-right: none;
    }
    #site-footer .copyright {
      font-size: 14px;
	  line-height: 22px;
      text-align: center;
      display: block;
      padding: 10px 0;
      color: #777;
    }
    #site-footer .copyright a{
      display: block;
      margin: 8px 0;
    }
    #site-footer .nav-footer-bar ul {
      padding: 0;
      margin: 0;
    }
    #site-footer h3{
      text-align: center;
      padding-top: 24px;
    }
    #site-footer li{
      text-align: center;
    }
    #site-footer p{
      text-align: center;
    }
    .footer-newsletter form{
      text-align: center;
    }
    #social-footer img {
      width: 30px;
      height: auto;
    }
    /* Newsletter styles */#mailinglist-header button, .mailinglist-page button {
      display: inline;
      height: 38px;
      vertical-align: top;
      margin-left: 8px;
      padding: 0 16px;
      background: #77bf15;
      border: 1px solid #77bf15;
      font-size: 14px;
      color: #fff;
    }
    #mailinglist-header input#email, .mailinglist-page input#email {
      width: 220px;
      height: 38px;
      display: inline;
      vertical-align: top;
      font-size: 14px;
    }
    /* New Button Class */.button{
      display: inline-block;
      vertical-align: top;
      height: 38px;
      margin: 8px 0;
      padding: 8px 16px;
      background: #77bf15;
      border: 1px solid #77bf15;
      font-size: 14px;
      color: #fff;
      border-radius: 5px;
    }
    /* 404 page fix */#post-not-found .search .navbar-right {
      float: left !important;
    }
    /* FONT OVERWRITES!!! */h1 {
      font-size: 32px;
    }
    h2 {
      font-size: 28px;
	  color: #333;
    }
    h3{
      font-size: 24px;
	  color: #333;
    }
    h4{
      font-size: 20px;
	  color: #333;
    }
    h5, h6{
      font-size: 16px;
	  color: #333;
    }
    }
    p, li{
      font-size: 14px;
    }
	
	.widget-title{
      color:#333;
    }
	
  </style>
  <!-- Dynamic Widgets by QURL loaded - http://www.dynamic-widgets.com //-->
  <style type="text/css" media="all"
         id="siteorigin-panels-layouts-head">/* Layout 22265 */ #pgc-22265-0-0 , #pgc-22265-2-0 {
           width:100%;
           width:calc(100% - ( 0 * 30px ) ) }
    #pg-22265-0 , #pg-22265-1 , #pl-22265 .so-panel {
      margin-bottom:20px }
    #pgc-22265-1-0 , #pgc-22265-1-1 {
      width:50%;
      width:calc(50% - ( 0.5 * 30px ) ) }
    #pl-22265 .so-panel:last-child {
      margin-bottom:0px }
    #pg-22265-0.panel-no-style, #pg-22265-0.panel-has-style > .panel-row-style , #pg-22265-1.panel-no-style, #pg-22265-1.panel-has-style > .panel-row-style , #pg-22265-2.panel-no-style, #pg-22265-2.panel-has-style > .panel-row-style {
      -webkit-align-items:flex-start;
      align-items:flex-start }
    @media (max-width:780px){
      #pg-22265-0.panel-no-style, #pg-22265-0.panel-has-style > .panel-row-style , #pg-22265-1.panel-no-style, #pg-22265-1.panel-has-style > .panel-row-style , #pg-22265-2.panel-no-style, #pg-22265-2.panel-has-style > .panel-row-style {
        -webkit-flex-direction:column;
        -ms-flex-direction:column;
        flex-direction:column }
      #pg-22265-0 .panel-grid-cell , #pg-22265-1 .panel-grid-cell , #pg-22265-2 .panel-grid-cell {
        margin-right:0 }
      #pg-22265-0 .panel-grid-cell , #pg-22265-1 .panel-grid-cell , #pg-22265-2 .panel-grid-cell {
        width:100% }
      #pgc-22265-1-0 {
        margin-bottom:30px }
      #pl-22265 .panel-grid-cell {
        padding:0 }
      #pl-22265 .panel-grid .panel-grid-cell-empty {
        display:none }
      #pl-22265 .panel-grid .panel-grid-cell-mobile-last {
        margin-bottom:0px }
    }
  </style>        
  <?php //HEAD end ?>
</head>

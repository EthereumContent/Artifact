<iframe width="900" height="20" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/510346770%3Fsecret_token%3Ds-G9Kbw&color=%23ff0000&inverse=true&auto_play=true&show_user=true"></iframe>


<iframe width="900" height="90%" scrolling="yes" frameborder="no" src="https://docs.google.com/document/d/e/2PACX-1vTljYuDQF9kfbizRO_4NuYYqMpTQ6n8XL2u94L0oWmaP3w8KtBcyKRVCyCk4nOnGzrK1gvgDYkLefvz/pub?embedded=true"></iframe>
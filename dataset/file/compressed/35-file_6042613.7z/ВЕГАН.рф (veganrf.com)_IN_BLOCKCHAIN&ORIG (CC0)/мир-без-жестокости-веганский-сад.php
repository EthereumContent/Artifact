<?php 
$pagetitle="Мир без жестокости (Веганский Сад)";//прописывается вручную для каждой страницы
$sidebarID="1"
?>

<html>

  <!--php_include/page-head.php-->
  <?php include 'php_include/page-head.php'; ?>
  <!--/php_include/page-head.php-->

	<body class="page-template-default page page-id-15730">
        <div id="wrap">
       <!--php_include/bodyhead.php-->
      <?php include 'php_include/all-bodyhead.php'; ?>
      <!--/php_include/bodyhead.php-->
    
            <main role="main">
                <div class="container" id="container">

<div id="content">

<style>
.page-title {color: #333;
font-size: 30px;}
#summary {color: #333;}
</style>
        
    <article id="post-15730" class="clearfix post-15730 page type-page status-publish has-post-thumbnail hentry category-reference" role="article" itemscope itemtype="http://schema.org/BlogPosting">
        <header class="article-header">
            <h1 class="page-title" itemprop="headline"><?php echo $pagetitle;?></h1>
                    </header>
        <section id="summary">Кажется недостижимой целью,<br />но мы не опустим руки и будем тянуться—изо–всех-сил</section>
        <section class="entry-content clearfix" itemprop="articleBody">
            <img width="675" height="250" src="http://веган.рф/files/image1.jpg" class="img-responsive featured-image-single wp-post-image" alt="Картина: “Опавшие листья” • Автор: Shinya Okayama • http://okayamashinya.com/" title="Картина: “Опавшие листья” • Автор: Shinya Okayama • http://okayamashinya.com/" sizes="(max-width: 675px) 100vw, 675px" />            
			
			<div class="last-update">Ссылка на источник — <a href="http://adaptt.org/animal-rights/the-garden-of-vegan.html" target="_blank">http://adaptt.org/animal-rights/the-garden-of-vegan.html</a></div>
            
			<p></p>
<blockquote><p>Веганство способно возродить Райский Сад и создать рай на Земле. Мы можем жить в таком обществе, где люди видят в животных друзей, а животные смотрят на людей с любопытной отчуждённостью и не видят в них угрозу.</p></blockquote>

	<p>Согласно теории сотворения мира люди были веганами задолго до того, как обратились к греховной диете, основанной на поедании плоти убитых животных. Многие религии недвусмысленно утверждают, что причинение вреда живым существам недопустимо, а к своему телу нужно относиться как к храму, питая его здоровой, не животной, пищей. Если вы являетесь последователем иудаизма, христианства или ислама, просто взгляните на Райский Сад — он был веганским, а Адам и Ева были первыми веганами на нашей планете.
	</p>
	
	<p>Это очень показательно: каждое общество, культура, раса, религия и этнос оправдывают употребление в пищу определённых животных, лишая их неотъемлемого права быть счастливыми и свободными, и в то же самое время осуждают причинение вреда другим животным, которых они произвольным образом решили защищать. Если бы люди всех национальностей, рас, религий и вероисповеданий собрались вместе за одним столом, только веганство могло бы всех объединить в вопросе еды, не оскорбив ничьих чувств. Русские сказали бы: "Мы не едим кошек и собак!". Мусульмане и ортодоксы заявили бы: "Мы не едим свиней!". Буддисты, Адвентисты Седьмого дня и индусы сказали бы: "Мы не едим коров, куриц, индеек и коз!". А джайны, растафариане и, конечно же, веганы исключили бы из своего обеда все продукты животного происхождения. Поэтому единственное, на чём мы ВСЕ в этом случае могли бы сойтись в вопросе питания — фрукты, овощи, орехи, семена, злаки и бобовые.
	</p>
	
	
	<p>Веганство способно возродить Райский Сад и создать рай на Земле. Мы можем жить в таком обществе, где люди видят в животных друзей, а животные смотрят на людей с любопытной отчуждённостью и не видят в них угрозу. <a href="http://www.care2.com/causes/scientists-proclaim-animal-and-human-consciousness-the-same.html#ixzz253x3jbNj" data-lity>Пришло время воссоединиться с природой ради животных</a>, окружающей среды и человечества. <a href="https://www.youtube.com/watch?v=BXlR8if5hok" data-lity>Защита слабых — первый шаг на пути к просветлению</a> и истинной цивилизованности. Без полного и безисключительного освобождения животных - на Земле не может быть мира. "Это решающая проверка на моральность для всего человечества, которая заключается в том, как мы относимся к тем, кто находится в нашей власти — к животным. И на сегодня человечество не прошло эту проверку, потерпев полное фиаско, настолько фундаментальное, что все остальные зверства прямо вытекают из него" (вольный перевод цитаты <a href="https://ru.wikipedia.org/wiki/%D0%9A%D1%83%D0%BD%D0%B4%D0%B5%D1%80%D0%B0,_%D0%9C%D0%B8%D0%BB%D0%B0%D0%BD" data-lity>Милана Кундера</a>).
	</p>


<h2>H2 Заголовок тест</h2>
<p>Lorem ipsum is a pseudo-Latin text used in web design, typography, layout, and printing in place of English to emphasise design elements over content. It's also called placeholder (or filler) text. It's a convenient tool for mock-ups. It helps to outline the visual elements of a document or presentation, eg typography, font, or layout. Lorem ipsum is mostly a part of a Latin text by the classical author and philosopher Cicero. Its words and letters have been changed by addition or removal, so to deliberately render its content nonsensical; it's not genuine, correct, or comprehensible Latin anymore. While lorem ipsum's still resembles classical Latin, it actually has no meaning whatsoever. As Cicero's text doesn't contain the letters K, W, or Z, alien to latin, these, and others are often inserted randomly to mimic the typographic appearence of European languages, as are digraphs not to be found in the original.</p>


<style>
hr.style15 {
	border-top: 4px double #8c8b8b;
	text-align: center;
}
hr.style15:after {
	content: '\002665';
	display: inline-block;
	position: relative;
	top: -15px;
	padding: 0 10px;
	background: white;
	color: #8c8b8b;
	font-size: 18px;
}
</style>

<hr class="style15">

<p>Список всех ссылок на данной странице:</p>

<ol class="easy-footnotes-wrapper-2018">
<li class="easy-footnote-single"><a href="https://www.care2.com/causes/scientists-proclaim-animal-and-human-consciousness-the-same.html#ixzz253x3jbNj" target="_blank">Scientists Proclaim Animal and Human Consciousness the Same</a> (care2.com)</li>
<li class="easy-footnote-single"><a href="https://www.youtube.com/watch?v=BXlR8if5hok" target="_blank">Vegans In Ancient Times | The History of Veganism Part One</a> (youtube.com)</li>
<li class="easy-footnote-single"><a href="https://ru.wikipedia.org/wiki/%D0%9A%D1%83%D0%BD%D0%B4%D0%B5%D1%80%D0%B0,_%D0%9C%D0%B8%D0%BB%D0%B0%D0%BD" target="_blank">Милан Кундера</a> (wikipedia.org)</li>
</ol>        



<img width="675" height="250" src="http://веган.рф/files/image2.jpg" class="img-responsive featured-image-single wp-post-image" alt="Автор картины: Roger Olmos • FAADA (http://www.faada.org/) and Logos Edizioni" title="Автор картины: Roger Olmos • FAADA (http://www.faada.org/) and Logos Edizioni" sizes="(max-width: 675px) 100vw, 675px" />



</section>
 



 
        <footer class="article-footer">
            
                    </footer>
        
                    
    </article>
        
    
</div>
<div id="sidebar" class="sidebar fourcol last clearfix" role="complementary">
	
		<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">Вступительные слова</h4></div>
		<p>
<ul>

<li><a data-lity href="https://disintegrationineternity.blogspot.com/2018/09/s-chego-nachat.html">С чего начать?</a></li>
<li><a data-lity href="https://disintegrationineternity.blogspot.com/2018/09/chto-posmotret.html">Что посмотреть?</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">Что есть?</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">Нравственность</a></li>
<li><a href="http://веган.рф/мир-без-жестокости-веганский-сад/">Мир без жестокости (Веганский Сад)</a></li>

</ul>	
		</p>
		
		
<!--		
				<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">Их голоса – наши голоса</h4></div>
		<p>
<ul>

                              <li>
                                <a style="color:#F83A22;" href="#test">Счётчик убийств
                                </a>
                              </li>
                              <li>
                                <a href="#test">Свиньи, кролики, козы и овцы
                                </a>
                              </li>
                              <li>
                                <a href="#test">Цыплята, яйца, обман про "свободный выгул"
                                </a>
                              </li>
                              <li>
                                <a href="#test">Коровы
                                </a>
                              </li>
                              <li>
                                <a href="#test">Молочные продукты
                                </a>
                              </li>
                              <li>
                                <a href="#test">Индюшки, утки и гуси
                                </a>
                              </li>
                              <li>
                                <a href="#test">Рыба и омега жирные кислоты
                                </a>
                              </li>
                              <li>
                                <a href="#test">Пчёлы и мёд
                                </a>
                              </li>
                              <li>
                                <a href="#test">Шкуры животных
                                </a>
                              </li>
                              а также:
                              <li>
                                <a href="#test">Animal Agriculture and Environmental Destruction
                                </a>
                              </li>
                              <li>
                                <a href="#test">Animal Agriculture and World Hunger
                                </a>
                              </li>
                              <li>
                                <a href="#test">GMOs, Pesticides, and Palm Oil
                                </a>
                              </li>

</ul>	
		</p>
		
		
						<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">Оправдания</h4></div>
		<p>
<ul>

<li>
                                <a href="http://www.adaptt.org/veganism/appeals-to-traditions-customs-and-habits.html">Appeals to Traditions, Customs, and Habits
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/the-killing-plants-argument.html">The “Killing Plants” Argument
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/the-meat-eating-is-natural-argument.html">The “Meat-Eating Is Natural” Argument
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/the-wrecking-the-economy-argument.html">The “Wrecking the Economy” Argument
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/the-prayer-vindicates-killing-argument.html">The “Prayer Vindicates Killing” Argument
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/the-burning-building-question.html">The “Burning Building” Question
                                </a>
                              </li>
                              <li>
                                <a href="https://www.youtube.com/watch?v=vyZBGxqgRUs">30 дней - 30 оправданий
                                </a>
                              </li>

</ul>	
		</p>
		
						<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">Быть веганом</h4></div>
		<p>
<ul>

 makin the transition to veganism
                              <li>
                                <a href="http://www.adaptt.org/resources/what-vegans-eat-wear-and-use.html">What Vegans Eat, Wear, and Use
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/becoming-a-new-vegan.html">Becoming a New Vegan
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/is-veganism-expensive.html">Is Veganism Expensive?
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/what-about-dogs-and-cats.html">What about Dogs and Cats?
                                </a>
                              </li>
                              the vegan shopping guide
                              <li>
                                <a href="http://www.adaptt.org/resources/vegan-meat-substitutes.html">Vegan Meat Substitutes
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/vegan-dairy-substitutes.html">Vegan Dairy Substitutes
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/vegan-egg-substitutes.html">Vegan Egg Substitutes
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/vegan-breads-bagels-and-other-baked-goods.html">Vegan Breads and Baked Goods
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/other-vegan-foods.html">Other Vegan Foods
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/clothing-body-care-and-cosmetics.html">Vegan Shoes, Clothing, Body Care, and Cosmetics
                                </a>
                              </li>
                              а также:
                              <li>
                                <a href="http://www.adaptt.org/resources/vitamins-minerals-and-other-nutrients.html">Vitamins, Minerals, and Other Nutrients
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/vegan-pregnancy-infants-and-children.html">Vegan Pregnancy, Infants, and Children
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/resources/vegan-athletes.html">Vegan Athletes
                                </a>
                              </li>

</ul>	
		</p>
		
						<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">Важное о правах животных</h4></div>
		<p>
<ul>

 <li>
                                <a href="http://www.adaptt.org/animal-rights/animal-intelligence.html">Animal Intelligence
                                </a>
                              </li>
                              что не так с:
                              <li>
                                <a href="#test">Что не так с зоопарками
                                </a>
                              </li>
                              <li>
                                <a href="#test">Что не так с цирками
                                </a>
                              </li>
                              <li>
                                <a href="#test">Что не так с родео и катанием на лошадях
                                </a>
                              </li>
                              <li>
                                <a href="#test">Что не так с охотой
                                </a>
                              </li>
                              <li>
                                <a href="#test">Что не так с вивисекций
                                </a>
                              </li>
                              а также:
                              <li>
                                <a href="#test">Empathy, Education, and Violence
                                </a>
                              </li>
                              <li>
                                <a href="#test">More Problems with Pacifism
                                </a>
                              </li>
                              <li>
                                <a href="#test">PETA and Homeless Animals
                                </a>
                              </li>
                              <li>
                                <a href="#test">Slavery—Animal and Human
                                </a>
                              </li>
                              <li>
                                <a href="#test">Four Myths about “Helper” Animals
                                </a>
                              </li>
                              религия и животные:
                              <li>
                                <a href="#test">The Qur'an and Islam
                                </a>
                              </li>
                              <li>
                                <a href="#test">The Bible, Jesus, and Veganism
                                </a>
                              </li>
                              а также:
                              <li>
                                <a href="#test">Quotes about Rights and Justice
                                </a>
                              </li>
                              <li>
                                <a href="#test">Неоднозначные сообщества и личности
                                </a>
                              </li>

</ul>	
		</p>
		
						<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">О диете</h4></div>
		<p>
<ul>

 <li>
                                <a href="https://www.vegan.com/animal-ingredients/">Список продуктов животного происхождения
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/humans-are-herbivores.html">Humans Are Herbivores
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/protein-and-trans-fatty-acids.html">Protein and Trans Fatty Acids
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/the-truth-and-falsehoods-about-soy.html">The Truth—and Falsehoods—about Soy
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/fad-diets.html">Fad Diets
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/hitler-and-vegetarianism-both-are-evil.html">Hitler and Vegetarianism: Both Are Evil
                                </a>
                              </li>
                              <li>
                                <a href="http://www.adaptt.org/veganism/evolution-and-creation.html">Evolution and Creation
                                </a>
                              </li>

</ul>	
		</p>
		
						<div id="text-423180017" class="widget widget_text"><h4 class="widgettitle">О будущем веганства</h4></div>
		<p>
<ul>

        <li>
                                <a href="/о-будущем-веганства/">О будущем веганства
                                </a>
                              </li>
                              <li>
                                <a href="/место-для-ваших-историй/">Место для ваших историй
                                </a>
                              </li>
                              <li>
                                <a href="/сообщества-движения-личности/">Сообщества, движения и личности, которые поддерживает ВЕГАН.рф
                                </a>
                              </li>

</ul>	
		</p>
-->		
		
		
		
		
<!-- Include jBox -->


<script type='text/javascript'>
var $jq16 = jQuery.noConflict();
</script>

<script src="http://global-perm.com/themes/citynews/jBox.min.js"></script>  

<script>

(function($) {

$(document).ready(function() {
 
 // Tooltip above and centered, this is the default setting
 $('.DemoTooltipAbove').jBox('Tooltip');
 
 // Tooltip below
 $('.DemoTooltipBelow').jBox('Tooltip', {
  closeOnMouseleave: true,
  width: 250,
  position: {
   x: 'center',
   y: 'bottom'
  }
 });
 
 // Tooltip with the pointer moved to the right
 $('.DemoTooltipPointer').jBox('Tooltip', {
  pointer: 'right:15' // The pointer is moved to the right with a 15 pixel offset
 });
 
 // Tooltip at a different target
 $('.DemoTooltipTarget').jBox('Tooltip', {
  target: jQuery('.DemoTooltipBelow')
 });
 
 // Tooltip with an offset
 $('.DemoTooltipOffset').jBox('Tooltip', {
  offset: {
   x: 30,
   y: -5
  }
 });
 
 // Tooltip to the left
 $('.DemoTooltipLeft').jBox('Tooltip', {
  position: {
   x: 'left',
   y: 'center'
  },
  outside: 'x' // Horizontal Tooltips need to change their outside position
 });
 
 // Tooltip to the right
 $('.DemoTooltipRight').jBox('Tooltip', {
  closeOnMouseleave: true,
  position: {
   x: 'right',
   y: 'center'
  },
  outside: 'x' // Horizontal Tooltips need to change their outside position
 });
 
 // Mouse following tooltips have the type "Mouse" instead of "Tooltip"
 $('.DemoTooltipMouse').jBox('Mouse', {
  content: 'I will follow you'
 });
 
});

}($jq16));

</script> 

<style>
/* JBOX >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */

/* Global */

.jBox-wrapper {
	text-align: left;
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
}

.jBox-title,
.jBox-content,
.jBox-container {
	position: relative;
	word-break: break-word;
}

.jBox-container {
	background: #fff;
}

.jBox-content {
	padding: 8px 10px;
	overflow: auto;
	-webkit-transition: opacity .15s;
	transition: opacity .15s;
}

/* jBox Tooltip */

.jBox-Tooltip .jBox-container,
.jBox-Mouse .jBox-container {
	border-radius: 3px;
	box-shadow: 0 0 5px rgba(0, 0, 0, .3);
}

.jBox-Tooltip .jBox-title,
.jBox-Mouse .jBox-title {
	padding: 8px 10px 0;
	font-weight: bold;
}

.jBox-hasTitle.jBox-Tooltip .jBox-content,
.jBox-hasTitle.jBox-Mouse .jBox-content {
	padding-top: 5px;
}

/* Pointer */

.jBox-pointer {
	position: absolute;
	overflow: hidden;
}

.jBox-pointer-top { top: 0; }
.jBox-pointer-bottom { bottom: 0; }
.jBox-pointer-left { left: 0; }
.jBox-pointer-right { right: 0; }

.jBox-pointer-top,
.jBox-pointer-bottom {
	width: 30px;
	height: 12px;
}

.jBox-pointer-left,
.jBox-pointer-right {
	width: 12px;
	height: 30px;
}

.jBox-pointer:after {
	content: '';
	width: 20px;
	height: 20px;
	position: absolute;
	background: #fff;
	-webkit-transform: rotate(45deg);
	transform: rotate(45deg);
}

.jBox-pointer-top:after {
	left: 5px;
	top: 6px;
	box-shadow: -1px -1px 4px rgba(0, 0, 0, .2);
}

.jBox-pointer-right:after {
	top: 5px;
	right: 6px;
	box-shadow: 1px -1px 4px rgba(0, 0, 0, .2);
}

.jBox-pointer-bottom:after {
	left: 5px;
	bottom: 6px;
	box-shadow: 1px 1px 4px rgba(0, 0, 0, .2);
}

.jBox-pointer-left:after {
	top: 5px;
	left: 6px;
	box-shadow: -1px 1px 4px rgba(0, 0, 0, .2);
}

/* jBox Modal & jBox Confirm */

.jBox-Modal .jBox-container,
.jBox-Confirm .jBox-container {
	border-radius: 3px;
	box-shadow: 0 3px 15px rgba(0, 0, 0, .4), 0 0 5px rgba(0, 0, 0, .4);
}

.jBox-Modal .jBox-title,
.jBox-Confirm .jBox-title {
	border-radius: 3px 3px 0 0;
	padding: 10px 15px;
	background: #f4f5f6;
	border-bottom: 1px solid #ddd;
	text-shadow: 0 1px 0 #fff;
}

.jBox-Modal.jBox-closeButton-title .jBox-title,
.jBox-Confirm.jBox-closeButton-title .jBox-title {
	padding-right: 55px;
}

.jBox-Modal.jBox-closeButton-box:before,
.jBox-Confirm.jBox-closeButton-box:before {
	box-shadow: 0 3px 15px rgba(0, 0, 0, .4), 0 0 5px rgba(0, 0, 0, .4);
}

/* jBox Modal */

.jBox-Modal .jBox-content {
	padding: 12px 15px;
}

/* jBox Confirm */

.jBox-Confirm .jBox-content {
	text-align: center;
	padding: 45px 35px;
}

.jBox-Confirm-footer {
	border-top: 1px solid #e2e2e2;
	background: #fafafa;
	border-radius: 0 0 3px 3px;
	text-align: center;
	padding: 10px 0;
}

.jBox-Confirm-button {
	display: inline-block;
	cursor: pointer;
	font-size: 15px;
	line-height: 30px;
	height: 30px;
	border-radius: 3px;
	padding: 0 20px;
	-webkit-transition: color .2s, background-color .2s;
	transition: color .2s, background-color .2s;	
}

.jBox-Confirm-button-cancel {
	text-shadow: 0 1px 1px rgba(255, 255, 255, .6);
	background: #ddd;
	color: #999;
	margin-right: 25px;
}

.jBox-Confirm-button-cancel:hover {
	background: #ccc;
	color: #666;
}

.jBox-Confirm-button-submit {
	text-shadow: 0 -1px 1px rgba(0, 0, 0, .2);
	background: #5fc04c;
	color: #fff;
}

.jBox-Confirm-button-submit:hover {
	background: #53a642;
}

.jBox-Confirm-button-cancel:active,
.jBox-Confirm-button-submit:active {
	box-shadow: inset 0 1px 3px rgba(0, 0, 0, .26);
}

/* jBox Notice */

.jBox-Notice {
	-webkit-transition: margin .2s;
	transition: margin .2s;
}

.jBox-Notice .jBox-container {
	border-radius: 3px;
	box-shadow: 0 0 3px rgba(0, 0, 0, .2);
	color: #fff;
	text-shadow: 0 -1px 0 #000;
	background: #333;
	background-image: linear-gradient(to bottom, #444, #222);
}

.jBox-Notice .jBox-content {
	border-radius: 3px;
	padding: 12px 20px;
}

.jBox-Notice .jBox-title {
	padding: 8px 20px 0;
	font-weight: bold;
}

.jBox-hasTitle.jBox-Notice .jBox-content {
	padding-top: 5px;
}

.jBox-Notice-color .jBox-container {
	text-shadow: 0 -1px 0 rgba(0, 0, 0, .3);
}

.jBox-Notice-gray .jBox-container {
	color: #666;
	text-shadow: 0 1px 0 #fff;
	background: #f4f4f4;
	background-image: linear-gradient(to bottom, #fafafa, #f0f0f0);
}

.jBox-Notice-red .jBox-container {
	background: #b02222;
	background-image: linear-gradient(to bottom, #ee2222, #b02222);
}

.jBox-Notice-green .jBox-container {
	background: #70a800;
	background-image: linear-gradient(to bottom, #95cc2a, #70a800);
}

.jBox-Notice-blue .jBox-container {
	background: #2b91d9;
	background-image: linear-gradient(to bottom, #5abaff, #2b91d9);
}

.jBox-Notice-yellow .jBox-container {
	color: #744700;
	text-shadow: 0 1px 0 rgba(255, 255, 255, .6);
	background: #ffb11f;
	background-image: linear-gradient(to bottom, #ffd665, #ffb11f);
}

/* jBox Image */

.jBox-Image {
	background: #fff;
	padding: 8px 8px 45px;
	border-radius: 5px;
}

.jBox-Image .jBox-content {
	padding: 0;
	width: 100%;
	height: 100%;
}

.jBox-image-container {
	border-radius: 5px;
	background: #000 center center no-repeat;
	position: absolute;
	width: 100%;
	height: 100%;
	opacity: 0;
}

.jBox-image-label {
	box-sizing: border-box;
	position: absolute;
	background: #fff;
	top: 100%;
	left: 0;
	width: 100%;
	color: #333;
	margin-top: -35px;
	padding: 0 90px 5px 10px;
	border-radius: 0 0 5px 5px;
	-webkit-transition: opacity .3s;
	transition: opacity .3s;
	opacity: 0;
}

.jBox-image-label.active {
	opacity: 1;
}

.jBox-image-pointer-next,
.jBox-image-pointer-prev {
	position: absolute;
	bottom: 0px;
	width: 22px;
	height: 45px;
	/*background: no-repeat center center url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9Ijc0LjcgMjI0IDE4LjcgMzIiPg0KPHBhdGggZmlsbD0iIzAwMDAwMCIgZD0iTTkzLDIyNy40TDgwLjQsMjQwTDkzLDI1Mi42YzAuNCwwLjQsMC40LDEuMSwwLDEuNWwtMS42LDEuNmMtMC40LDAuNC0xLDAuNS0xLjUsMEw3NSwyNDAuN2MtMC40LTAuNC0wLjUtMSwwLTEuNWwxNC45LTE0LjljMC40LTAuNCwxLTAuNCwxLjUsMGwxLjYsMS42QzkzLjUsMjI2LjQsOTMuNCwyMjcsOTMsMjI3LjR6Ii8+DQo8L3N2Zz4=);*/
	background-size: 11px auto;
	cursor: pointer;
	opacity: .6;
	-webkit-touch-callout: none;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	-webkit-transition: opacity .2s;
	transition: opacity .2s;
}

.jBox-image-pointer-next:hover,
.jBox-image-pointer-prev:hover {
	opacity: 1;
}

.jBox-image-pointer-next {
	right: 8px;
    -webkit-transform: scaleX(-1);
    transform: scaleX(-1);
}

.jBox-image-pointer-prev {
	right: 30px;
}

.jBox-image-open #jBox-overlay {
	background-color: rgba(0, 0, 0, .86);
}

.jBox-Image.jBox-loading .jBox-container:before {
	left: auto;
	top: auto;
	bottom: -33px;
	right: 55px;
	margin-top: -9px;
	margin-left: -9px;
}

/* Close button */

.jBox-closeButton {
	cursor: pointer;
	position: absolute;
}

.jBox-closeButton svg {
	position: absolute;
	top: 50%;
	right: 50%;
}

.jBox-closeButton path {
	-webkit-transition: fill .2s;
	transition: fill .2s;
}

.jBox-closeButton path {
	fill: #aaa;
}

.jBox-closeButton:hover path {
	fill: #888;
}

.jBox-closeButton:active path {
	fill: #666;
}

/* Close button in overlay */

#jBox-overlay .jBox-closeButton {
	top: 0;
	right: 0;
	width: 40px;
	height: 40px;
}

#jBox-overlay .jBox-closeButton svg {
	width: 20px;
	height: 20px;
	margin-top: -10px;
	margin-right: -10px;
}

#jBox-overlay .jBox-closeButton path {
	fill: #d2d4d6;
}

#jBox-overlay .jBox-closeButton:hover path {
	fill: #fff;
}

#jBox-overlay .jBox-closeButton:active path {
	fill: #b2b4b6;
}

/* Close button in title */

.jBox-closeButton-title .jBox-closeButton {
	top: 0;
	right: 0;
	bottom: 0;
	width: 40px;
}

.jBox-closeButton-title .jBox-closeButton svg {
	width: 12px;
	height: 12px;
	margin-top: -6px;
	margin-right: -6px;
}

/* Close button in box */

.jBox-closeButton-box .jBox-closeButton {
	top: -8px;
	right: -10px;
	width: 24px;
	height: 24px;
	background: #fff;
	border-radius: 50%;
}

.jBox-closeButton-box .jBox-closeButton svg {
	width: 10px;
	height: 10px;
	margin-top: -5px;
	margin-right: -5px;
}

.jBox-hasTitle.jBox-Modal.jBox-closeButton-box .jBox-closeButton {
	background: #f4f5f6;
}

.jBox-closeButton-box:before {
	content: '';
	position: absolute;
	top: -8px;
	right: -10px;
	width: 24px;
	height: 24px;
	border-radius: 50%;
	box-shadow: 0 0 5px rgba(0, 0, 0, .3);
}

.jBox-pointerPosition-top.jBox-closeButton-box:before {
	top: 4px;
}

.jBox-pointerPosition-right.jBox-closeButton-box:before {
	right: 2px;
}

/* Overlay */

#jBox-overlay {
	position: fixed;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
	background: #000;
	background-color: rgba(0, 0, 0, .6);
}

/* Block scrolling */

body[class^="jBox-blockScroll-"],
body[class*=" jBox-blockScroll-"] {
	overflow: hidden;
}

/* Draggable */

.jBox-draggable {
	cursor: move;
}

/* Spinner */

@keyframes jBoxLoading {
	to {transform: rotate(360deg);}
}

@-webkit-keyframes jBoxLoading {
	to {-webkit-transform: rotate(360deg);}
}

.jBox-loading .jBox-content {
	min-height: 30px;
	min-width: 30px;
	opacity: 0;
}

.jBox-loading .jBox-container:before {
	content: 'LoadingтАж';
	position: absolute;
	top: 50%;
	left: 50%;
	width: 16px;
	height: 16px;
	margin-top: -10px;
	margin-left: -10px;
	text-align: center;
}

.jBox-loading .jBox-container:not(:required):before {
	content: '';
	border-radius: 50%;
	border: 2px solid rgba(0, 0, 0, 0.3);
	border-top-color: rgba(0, 0, 0, 0.6);
	-webkit-animation: jBoxLoading .6s linear infinite;
	animation: jBoxLoading .6s linear infinite;
}

/* IE8 fixes */

.jBox-IE8.jBox-Tooltip .jBox-container,
.jBox-IE8.jBox-Mouse .jBox-container {
	border: 1px solid #aaa;
}

.jBox-IE8 .jBox-pointer:after {
	display: none;
}

.jBox-IE8 .jBox-pointer {
	border: 0;
	/*background: no-repeat url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAbCAYAAACN1PRVAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAPJJREFUeNq01l0OwyAIAGAlvY+n8ZJ6Gk/EqqkNtf7ApCQ+LM34iuCmRUQzihjj6FH+kjWL8N4/Ph9GHpiTnC9SwDbhLGyvspSScc71KkOa/HpuuRhIK+psE2pjONouCQg7kBSEXUgC2tHo52mTTBpnaEATWlaYK6MrhIAaceWpOcsCrYp6FV4H/90zTWjUQ/gSevVQq0ecHqoOxWpYoO7p5O9ku2fnVtp7QAik2rsK3fnpWfjynJWpbw+1BkghurrYDjiCptg/4AxaYhJwBbEwDsiB2NgM5EIirAdKIDFGQSmU1+NaIPjJYt2I25vxT4ABAMhWvtle2YvmAAAAAElFTkSuQmCC);*/
}

.jBox-IE8 .jBox-pointer-top { background-position: center top; }
.jBox-IE8 .jBox-pointer-bottom { background-position: center bottom; }
.jBox-IE8 .jBox-pointer-left { background-position: left center; }
.jBox-IE8 .jBox-pointer-right { background-position: right center; }

.jBox-IE8.jBox-Modal .jBox-container {
	border: 3px solid #aaa;
}

.jBox-IE8 .jBox-closeButton:after {
	font-family: Verdana, sans-serif;
	content: 'x';
	text-align: center;
	font-size: 18px;
}
</style>


<!-- /Include jBox -->		
		
		
		
<center>		
<другие разделы сайта>
</center>	

<ul>

<li><a style="color:grey;" href="#vegan" onclick="return false">Их голоса – наши голоса</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">Оправдания</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">Быть веганом</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">Важное о правах животных</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">О диете</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">О будущем веганства</a></li>
<li><a style="color:grey;" href="#vegan" onclick="return false">Не нашли нужную информацию?</a></li>


</ul>	

	
		</div>				
			
			
</div></div>

</div>
            </div><!-- main container-->
        </main>
    </div><!--wrap-->

	
<?php include 'php_include/all-footer.php'; ?>

   
</body>
</html>